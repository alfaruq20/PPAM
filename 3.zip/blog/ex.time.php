<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
   

    <title>Blog Template for Bootstrap</title>

    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="blog.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <div class="blog-masthead">
      <div class="container">
              <nav class="blog-nav">
          <a class="blog-nav-item" href="../">Home</a>
          <a class="blog-nav-item" href="N.santri.php">Santri Baru</a>
          <a class="blog-nav-item" href="PPAM.php">seputar PPAM</a>
          <a class="blog-nav-item " href="MDAM.php">Seputar MDAM</a>
          <a class="blog-nav-item active" href="ex.time.php">Extra time</a>
        </nav>
  
      </div>
    </div>

    <div class="container">

      <div class="blog-header">
        <h1 class="blog-title">AL Ma'ruf Extra kegiatan</h1>
        <p class="lead blog-description"> Untuk Meningkatkan Skill  Santri</p>
      </div>

      <div class="row">

        <div class="col-sm-8 blog-main">

          <div class="blog-post">
            <h4 > Kegiatan Jammiyah Malam jumat </h4>
           

            <p>Setiap malam jumat. agenda rutin tahlil  dimulai stelah sholat maghrib berjamaah kemudian diteruskan dengan sholat isya' berjamaah, pukul 20.00 wib para santri sudah harus berkumpul di mushola guna mengikuti agenda jammiyah, jammiyah langsung di koordinir oleh seksi keagamaan dan pendidikan dari mulai penjadwalan tugas santri sampai sistem acara yang akan dilaksanakan.</p>
            <p> jammiyah sendiri dimulai dengan pembacaan diba'i atau berjanji, setelah itu diteruskan dengan agenda melatih skiil santri dari mualai belajar menjadi bilal jumat, sholat ied, pidato, sampai latihan mengurus mayyit. diharap adanya forum jammiyah ini dapat melatih santri saat sudah terjun kemasyarakat nanatinya.</p>
            <hr>
                                <blockquote>
              <h4> kegiatan  Belajar membaca Al Quran </h4>
              <p> agenda ini sudah terjadwal setelah sholat maghib berjama'ah. teknisnya para santri dibagi menjadi beberapa regu. satu regu berisikan 5 sampai 6 santri dan satu regu di mentori atau di ajar oleh satu Ustadz. materinya pn berbeda beda karna menyesuaikan dari kemampuan santri itu sendiri. metodhe hafalan juz tiga puluh di terapkan di bebrapa regu dan pada akhir tahun pada moment haflah akhirussanah  santri yang telah lolos tes akan di wisuda</p>


            </blockquote>

            <br>
            <hr>
            <h4>Belajar rebana</h4>
            <p> kegiatan extra ini di lakukan pada hari kamis sore di pondok putra dan hari jumat sore di pondok putri. tidak main-main pengurus sie pendidikan langsung mendatangkan guru dari luar untuk dapat mengajari teman teman santeri sehingga dapat handal dalam bemain rebana.</p>

            <h4>masih banyak lagi agenda agenda yang ada dipondok pesantren alma'ruf yang belum kami expose. tunggu updatan kami ya.</h4>

           </div><!-- /.blog-post -->

           </div><!-- /.blog-sidebar -->

      </div><!-- /.row -->

    </div><!-- /.container -->

   <footer class="blog-footer">
    <div class="container" align="center" style="background-color :#333;">
    

      <p> Copy_right 2016  Desain by <a href="">Alfaruq</a>.
      </p>
      
        
      
    </div>
    <span class="col-sm- pull-right"><a href="#" align = "right">Back to top</a></span>
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="jquery.min.js"><\/script>')</script>
    <script src="bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
