<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
   

    <title>Blog Template for Bootstrap</title>

    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="blog.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <div class="blog-masthead">
      <div class="container">
              <nav class="blog-nav">
          <a class="blog-nav-item" href="../">Home</a>
          <a class="blog-nav-item" href="N.santri.php">Santri Baru</a>
          <a class="blog-nav-item" href="PPAM.php">seputar PPAM</a>
          <a class="blog-nav-item active" href="MDAM.php">Seputar MDAM</a>
          <a class="blog-nav-item" href="ex.time.php">Extra time</a>
        </nav>
  
      </div>
    </div>

    <div class="container">

      <div class="blog-header">
        <h1 class="blog-title">Madrasah Diniyah Al Ma'ruf</h1>
        <p class="lead blog-description"> MDAM</p>
      </div>

      <div class="row">

        <div class="col-sm-8 blog-main">

          <div class="blog-post">
            <h4 class="blog-post-title"> Sejarah Singkat MDAM </h4>
            <p class="blog-post-meta">July 20, 2016 by <a href="#">Faruq</a></p>

            <p>Madrasah diniyah Pondok pesantren Al Ma'ruf atau leih akrab di sebut oleh santri dengan singkatan MDAM</p>
            <hr>
                                <p>Madrasah Diniyah Al Ma’ruf (MDAM) didirikan tanggal 1987. 
                    Pada tahun 1993 MDAM masih berbentuk pengajian, baru ada satu 
                    ruangan yang dipisah dengan sekat menjadi tiga, itupun baru dua 
                    orang pengajar. Pada tahun 1993 jumlah santri kurang lebih 20 orang, 
                    sampai pada tahun 1994 model kelas-kelas masih belum ada. System 
                    muhafadzah baru ada pada tahun 1994, kemudian tahun berikutnya 
                    baru ada ujian koreksian kitab dan bahtsul masa’il. MDAM pertama 
                    kali dipimpin oleh Ust. Widodo Ahmad, yang kini menjadi pengasuh 
                    Pondok Pesantren Al Husna barat.</p>

                    <p>MDAM telah banyak Meluluskan Santri dari tahun ke tahun, kader lulusan pondok terus dicetak dari pendidikan madrasah pondok pesantren al ma'ruf ini. hingga kini ditahun 2016 MDAM telah memiliki gedung lokal santri  sebanyak  empat kelas, di tahun 2015 MDAM merubah kurikulum menggunakan Sistem Prakom yang hanya memiliki dua tingkatan Assasiyah dan kelas stanawiyah, dengan harapan para santri dapat membaca kitab dan mengamalkannya</p>
              <blockquote>
              <h3>Beberapa kitab Yang di kaji di MDAM</h3>
              
              <ul>
                <li> kitab fathul Qorib</li>
                <li> kitab tasrif</li>
                <li> kitab fathul mu'in</li>
                <li>kitab Alfiah </li>
              </ul>


            </blockquote>
           </div><!-- /.blog-post -->

           </div><!-- /.blog-sidebar -->

      </div><!-- /.row -->

    </div><!-- /.container -->

   <footer class="blog-footer">
    <div class="container" align="center" style="background-color :#333;">
    

      <p> Copy_right 2016  Desain by <a href="">Alfaruq</a>.
      </p>
      
        
      
    </div>
    <span class="col-sm- pull-right"><a href="#" align = "right">Back to top</a></span>
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="jquery.min.js"><\/script>')</script>
    <script src="bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
