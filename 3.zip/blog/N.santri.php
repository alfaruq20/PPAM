<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
   

    <title>Blog Template for Bootstrap</title>

    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="blog.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <div class="blog-masthead">
      <div class="container">
        <nav class="blog-nav">
          <a class="blog-nav-item" href="../">Home</a>
          <a class="blog-nav-item active" href="#">Santri Baru</a>
          <a class="blog-nav-item" href="PPAM.php">seputar PPAM</a>
          <a class="blog-nav-item" href="MDAM.php">Seputar MDAM</a>
          <a class="blog-nav-item" href="ex.time.php">Extra time</a>
        </nav>
      </div>
    </div>

    <div class="container">

      <div class="blog-header">
        <h1 class="blog-title"> Informasi Pendaftaran Santri Baru </h1>
        <p class="lead blog-description">Pondok Pesantren Al Ma'ruf Bandar lor Kota kediri</p>
      </div>

      <div class="row">

        <div class="col-sm-8 blog-main">

          <div class="blog-post">
            <h2 class="blog-post-title">Pendaftaran Santri Baru</h2>
            <p class="blog-post-meta"> juli 20, 2016 oleh <a href="#">al faruq</a></p>

            <p>pendaftaran santri baru pondok persantren al Ma'ruf dibuka setiap ajaran baru, namun bayak santri pindahan yang 
            daftar saat pondok sudah aktif.</p>
            <hr>
            <h2>Persyaratan Pendaftar </h2>
            <hr>
            <blockquote>
              <ul>
                <li>mengisi form pendaftaran    </li>
                <li> foto copy KTP 2 lembar     </li>
                <li>foto ukuran 3x4  dua lembar </li>
                <li>Membayar daftar ulang       </li>
                  <ul>
                      
                      <table>
                        <tr>
                           <td>administrasi daftar </td>
                           <td>:</td>
                           <td>Rp 10.000,00</td>
                        </tr>
                        <tr>
                           <td>uang gedung </td>
                           <td>:</td>
                           <td>Rp 350.000,00</td>
                        </tr>
                        <tr>
                           <td>Listrik Dan Kebersihan </td>
                           <td>:</td>
                           <td>Rp 200.000,00</td>
                        </tr>
                        <tr>
                           <td>Sekretariatan </td>
                           <td>:</td>
                           <td>Rp 50.000,00</td>
                        </tr>
                        <tr>
                           <td>Kos Makan dua bulan</td>
                           <td>:</td>
                           <td>Rp 200.000,00</td>
                        </tr>


                      </table>



                  </ul>
              </ul>
            </blockquote>
            <hr>
            <h2>Rincian Tambahan</h2>
            <hr>
                  <p>
                  <blockquote>
                    
                    <ul>
                      <li>listrik laptop : Rp 10.000,00</li>

                    </ul>

                  </blockquote> 
                  </p>
            <h3>Tempat Pendaftaran</h3>
            <p>pendaftaran dapat di layani langsung di kantor Sekretariatan Pondk Pesantren Al Ma'ruf Kedunglo </p>
            <hr>
            <br>
            <h3> Contact Person</h3>
            <p> ANda dapat Menghubudi langsung, atau mengirim Email yang ada dibawah ini</p>
            <pre> Bambang Prasetyo :  <code>085608555777 </code>
            <br> Email : PPAM@gmail.com
            </pre>
           <br>

           <footer class="blog-footer">
    <div class="container" align="center" style="background-color :#333;">
    

      <p> Copy_right 2016  Desain by <a href="">Alfaruq</a>.
      </p>
      
        
      
    </div>
    <span class="col-sm- pull-right"><a href="#" align = "right">Back to top</a></span>
    </footer>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="jquery.min.js"><\/script>')</script>
    <script src="bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
